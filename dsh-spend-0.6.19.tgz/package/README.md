# dsh-spend

> Token usage & cost monitor for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) — floating widget with multi-dimensional stats, time-series charts, auto-detected billing plans (Code/Token) and estimated spend.
>
> dsh 用量与计费仪表盘：token 调用量、按模型 / 供应商 / 时间统计、预计费用，自动识别订阅制（Code）与按量（Token）计费计划。

简体中文 | [English](README.en.md)

在 dsh Web UI 右下角显示一个**悬浮用量窗口**：实时查看 token 调用量、多维度统计与预计计费金额，**零配置**自动识别计费计划并直读订阅商真实额度/余额。

> 本分支相对上游的分歧记录见 [FORK.md](FORK.md)——同步上游前请先读。

## 目录

- [功能特性](#功能特性)
- [界面预览](#界面预览)
- [交互方式](#交互方式)
- [供应商自动识别（零配置）](#供应商自动识别零配置)
- [工作原理](#工作原理)
- [安装](#安装)
- [配置](#配置)
- [价格来源与计费口径](#价格来源与计费口径)
- [目录结构](#目录结构)
- [说明与边界](#说明与边界)

---

## 0.6.6 变更

- 面向 DeepSeek Harness `0.1.3-alpha.1` 发布，Harness peer 依赖声明为 `^0.1.3-alpha.1`。

## 0.6.5 变更

- 模型选择菜单中的输入、缓存读写和输出单价固定以人民币显示，不再跟随 Spend 仪表盘的美元/人民币切换。

## 0.6.4 变更

- 将 Cordis 与 Harness peer 依赖对齐到 `0.1.2-alpha.3`，确保包管理器接受 Alpha.3 宿主；保留 0.6.3 已采用的显式 `usageStats` client 注入与卸载清理。

## 0.6.3 变更

- 修复 Cordis v4 浏览器端在挂载 Spend Remote 后未经精确注入直接读取 `remote.usageStats` 的启动错误。插件现在先挂载贡献，再注入 `remote.usageStats` 并把取得的 client 传给全部统计与价表调用，卸载时释放挂载贡献；宿主提供的 `remote.session` 继续作为静态依赖注入，不参与动态挂载。

## 功能特性

- 🖱️ **三级交互**：悬浮胶囊常驻 → hover 摘要预览 → 点击展开四标签页详情面板
- 📊 **多维统计**：按提供商 / 模型 / 小时 / 天 / 会话 / 工作目录 / 最近调用，含性能指标（TTFT、生成速度）
- 📈 **时间序列图表**：今日逐小时、24h/72h/7d 时间曲线、52 周活跃热力图
- 🏷️ **计费计划自动识别**：内置知识库（17 供应商 / 131 模型价格），自动区分订阅制（Code）与按量（Token）
- 🔴 **实时额度 / 余额直读**：9 家订阅商内置适配器（额度 7 + 余额 2），展示厂商接口返回的真实值，失败安全回退不崩溃
- ⚡ **DeepSeek 峰谷计价**：8/17 起按调用时刻自动按高峰/空闲价计费
- 💱 **$ / ¥ 货币切换**：实时汇率（失败回退 `usdCnyRate`，默认 7.2）
- 📂 **工作区筛选**：按项目限定全部统计口径，支持逐级下钻子目录
- 📤 **数据导出**：调用明细支持 CSV / JSON / 调用明细 CSV 导出，可在独立窗口查看
- 🔁 **自动刷新**：默认 30s（服务端下发，页面无需改动），面板内也可手动刷新

模型选择菜单会在每个模型名称下仅用人民币显示输入、缓存读、缓存写和输出单价（每百万 Token），不跟随仪表盘的美元/人民币切换。页面启动时立即同步当前可见模型目录与 Spend 价表，管理员修改内部价格后立即刷新；此后每 24 小时再次同步。没有精确或通用模型价格的路由明确显示“未计价”，不会把仪表盘的默认估价冒充为个人扣费价格。

## 按用户计费账本与访问控制

插件同时维护一个独立 SQLite 消费账本。只接收带认证 principal 的最终 `assistant/message` usage，以 `(sessionId, turn, step)` 为唯一键；实时事件、日志重放和进程重启不会重复扣费。共享 Session 中每个 turn/step 使用其耐久事件上的消息身份，用户 A 与用户 B 不会串账。旧版 agent-loop 未把 principal 写入 turn/step 时，会从该 turn 内已认证的 `user/message` 回填身份后再入账。

账本金额全部使用人民币微元整数（`¥1 = 1,000,000 micros`）。配置价格是 USD/百万 Token，并以固定 `usdCnyRate` 折算；每笔记录固化价格版本、汇率版本、输入/输出/缓存读写/推理 Token、命中的价表和人民币金额。已计价记录不会因以后改价而变化。

个人扣费只接受 provider/model 精确价或明确的通用 model 价。未匹配模型记为“未计价”、输出一次告警且金额为 0；管理员补充精确价后可重新扫描计价，绝不使用 `defaultPricing` 模糊扣款。现有仪表盘仍可用 `defaultPricing` 展示估算，但该估算不参与 `dsh-passwords` 的个人额度判断。

`dsh-plugin-subscriptions` 注册的 `codex` 会自动归一化为 `openai-codex`；`gpt-5.5`、`gpt-5.4`、`gpt-5.4-mini` 和 `gpt-5.3-codex-spark` 上报的 Token 用量均按内置参考价进入个人账本和月额度判断。这个金额只是面向客户的内部折算，不是 ChatGPT 订阅之外的实际账单；`gpt-5.3-codex-spark` 因无独立公开价格而沿用 `gpt-5.3-codex` 单价。显式 `pricing` 仍可覆盖任一模型的内部单价。

管理员可在 Spend 面板“调用明细 → 计费单价”中为任意 provider/model 新增或编辑内部价格，按面板当前币种填写每百万 Token 的输入、输出、缓存读取和缓存写入价格。自定义价格持久化在同一 SQLite 账本中，优先级高于配置和内置知识库并立即用于新调用；未计价历史会自动补价，已计价历史保持原价格版本。子账号只能查看费率，不能新增、修改或删除。

`usageStats/query` 从 Typert Gateway 取得传输层已认证 principal，忽略浏览器声称的身份。普通用户的面板与 CSV/JSON/调用明细导出只包含自己的调用，且不返回或渲染订阅计划、档位、固定月费与计划用量；其预计金额只按本人 Token 用量计算。管理员默认查看全部，也可在面板选择“仅管理员”或指定子账号，服务端再按 `principalId` 隔离统计。匿名调用被拒绝。源码模式 Remote 标记无需生成描述文件，本地 `link:` 安装与发布包行为一致。内部 `spendAccounting` 服务提供自然月已用金额、额度状态和按权限报告，供 `dsh-passwords` 在每个模型步骤前同步检查。

每次模型调用前的额度检查都会先把最新模型用量同步到账本；此外，`syncIntervalHours`（默认 24 小时）会执行独立的后台全量对账，即使没有人打开 Spend 面板也会补齐各模型的最新用量。后台扫描会分批让出事件循环，不会因历史会话较多阻塞 Web 服务。同步使用 `(sessionId, turn, step)` 幂等键，不会因为每日重扫而重复扣费。

自然月固定按 `Asia/Shanghai` 计算。`dsh-passwords` 会向本插件注册当前账号的月额度解析器，Spend 面板和悬浮预览实时显示该账号的人民币剩余额度；额度修改不会被统计缓存冻结。`monthlyBudget` 仅是部署总预算的展示值，不参与个人额度门控；订阅固定月费也不分摊到个人账本。

仪表盘默认使用人民币，宿主统一以 USD 计算基础快照。价表始终按 USD/百万 Token 配置，浏览器再按实时或固定 `usdCnyRate` 换算单价、费用、自动识别的订阅费和金额额度，避免仅替换货币符号造成金额错误。

## 界面预览

![仪表盘总览](docs/screenshots/dashboard.png)

![调用明细窗口](docs/screenshots/details-window.png)

## 交互方式

| 层级 | 内容 |
|---|---|
| **悬浮胶囊**（右下角） | 始终显示预计费用与总 Token（超预算变黄/变红告警） |
| **hover** | 摘要预览：费用、Token、输入 / 输出 / 缓存读、调用次数、**今日小计** |
| **点击展开** | 四标签页详情面板；顶部**工作区筛选**下拉（按项目限定统计、逐级下钻子目录），标签栏右侧 **$ / ¥ 货币切换**按钮（悬停预览同款；汇率由服务端实时拉取，失败回退 `usdCnyRate` 固定值） |

### 四个标签页

- **总览**（纯 KPI + 排名摘要，无图表）：
  - **统计栏**：预计花费（月）+ 构成、**当月预计**（本月按量外推）、按 token 估算、总 Token、调用、会话、**平均 / 次**、**缓存命中率**、**月预算**（可选配置，超 80% 胶囊变黄、超 100% 变红）、**活跃天数 / 连续使用**；
  - **计划用量**：自动识别 Code/Token 计划、档位、额度使用与剩余；
  - **费用 Top 提供商 / Top 模型**（各 6 行）+ 近 31 天趋势。
- **今日**：当天调用数、Token 与费用小结 + **今日逐小时** Token / 费用图（横轴从当天**首个有调用的小时**起算，避免凌晨空白；当天无调用时窗口收敛到当前小时）+ **时间曲线**（默认近 24 小时，可切换 **24h / 72h / 7d**，首个有调用的小时起算，跨天处自动标注日期）+ **活跃热力图**（近 52 周，GitHub 风格，颜色深度 = 当日 Token 量，悬停看 Token / 费用 / 调用）。
- **性能**：每模型的**首字延时（TTFT）均值 / P50 / P90、生成速度（tokens/s）、总延迟均值** + 按小时的 TTFT / 速度曲线（支持 **24h / 72h / 7d** 切换，首个有样本的小时起算）。
- **调用明细**：**每会话 × 模型**的调用次数、token 与费用明细 + **按工作目录统计**（各项目会话数 / 模型数 / 调用 / 费用）+ **按会话统计** + **最近调用**（**费用远超均值的异常调用标红点**）+ **计费单价表**。可在**独立窗口**打开（随主窗口自动刷新，支持 **CSV / JSON / 调用明细 CSV 导出**）。

## 供应商自动识别（零配置）

插件内置**供应商知识库**（`lib/knowledge.js`，2026-08-27 官方文档核实）：**17 个供应商 / 159 个模型价格**。provider id 自动归一化别名：`glm`→zhipu、`kimi`→moonshot、`dashscope`→qwen、`gemini`→google、`grok`→xai、`claude`→anthropic、`copilot`→github-copilot、`minimax-cn`→minimax、`deepseek-official`→deepseek 等。日志中出现的提供商**自动匹配**知识库生成计划与价格（UI 标记"自动识别"）；显式 `plans` / `pricing` 配置始终覆盖自动识别。

### 订阅制（Code 计划）— 自动识别档位费与额度

| 供应商 | 默认档 | 档位 | 额度口径 |
|---|---|---|---|
| OpenCode Go（`opencode-go`） | $10/月 | — | **实时额度**（官方 `GET /zen/go/v1/usage`：5h/周/月 实际已用百分比 + 重置时间）；接口不可用时回退周 $30（V4 Flash 约 79,050 请求/周） |
| OpenAI Codex（`openai-codex`） | Plus $20/月 | Plus / Pro 5x $100 / Pro 20x $200 / Business | **实时额度**（`chatgpt.com/backend-api/wham/usage`，需本机 `~/.codex/auth.json` 登录态；未登录回退 ~100 请求/周） |
| GitHub Copilot（`github-copilot`） | Pro $10/月 | Free / Pro / Pro+ $39 / Max $100 / Business / Enterprise | **实时额度**（`api.github.com/copilot_internal/user`，需 `GH_TOKEN`/`GITHUB_TOKEN` 或 `gh auth login`；未登录回退 AI Credits 月 $15） |
| Claude Code（`claude-sub`） | Pro $20/月 | Pro / Max 5x $100 / Max 20x $200 | **实时额度**（`api.anthropic.com/api/oauth/usage`，需本机 `~/.claude/.credentials.json` 登录态；未登录回退档位表 5h 1x/5x/20x） |
| 智谱 Coding Plan（`zhipu`） | 官方套餐 | — | **实时额度**（官方 `bigmodel.cn/api/monitor/usage/quota/limit`：5h/周 已用百分比 + 重置时间、MCP 月度次数；凭据缝 `ZHIPU_API_KEY`；国际站 z.ai 可用 `usageEndpoints` 换 URL） |
| MiniMax Token Plan（`minimax`） | 官方套餐 | — | **实时额度**（官方 `minimaxi.com/v1/token_plan/remains`：5h/周 剩余百分比 + 重置时间；凭据缝 `MINIMAX_API_KEY`，兜底 `MINIMAX_CN_API_KEY`；国际站 minimax.io 可用 `usageEndpoints` 换 URL） |
| ClinePass（`clinepass`） | 官方套餐 | — | **实时额度**（官方 `api.cline.bot/v1/users/me/plan/usage-limits`：300 分钟/周/月 已用百分比 + 重置时间；凭据缝 `CLINEPASS_API_KEY`） |
| Google AI / Gemini CLI（`google-ai-sub`） | AI Pro $19.99/月 | AI Pro / Ultra 5x $99.99 / Ultra 20x $199.99 | 无公开用量接口，按官方每日上限（1,500 / 2,000 请求/天）展示 |

### 按量计费（Token 计划）— 自动带官方价

| 供应商 | 已收录模型 |
|---|---|
| OpenAI（`openai`） | gpt-5.6 sol/terra/luna、gpt-5.5、gpt-5.4 系、gpt-5 系、gpt-5.2、o3/o4-mini/o1 |
| Anthropic（`anthropic`） | claude-opus-5、sonnet-5、haiku-4-5、fable-5、opus/sonnet-4.x |
| Google（`google`） | gemini-3.7/3.6/3.5 flash、3.1-pro、2.5 pro/flash/lite |
| xAI（`xai`） | grok-4.6、4.5、4.3、build-0.1 |
| Mistral（`mistral`） | large-3、medium-3.5、small-4、ministral-3 |
| Moonshot（`moonshot`） | kimi-k3、k2.7-code |
| 智谱（`zhipu`，兼容 `zai` / `z-ai` / `glm`） | GLM-5.3-Flash、5.2、5.1、5-Turbo、5V-Turbo、5、4.7、4.5 |
| 阿里（`qwen`） | qwen3.8-max、3.7-max/plus/flash |
| MiniMax（`minimax`） | m3、m2.7 |
| OpenRouter（`openrouter`） | 实时目录 50 个热门模型 |
| OpenCode Zen（`opencode-zen`） | PAYG 网关价（Claude/GPT/Gemini/Grok/DeepSeek） |
| DeepSeek（`deepseek`） | v4-flash、v4-pro |

GLM-5.3-Flash 按官方 5 折活动价计费至 2026-09-09 24:00（UTC+8），之后自动切换为原价；历史调用始终按各自发生时间对应的价格计算。

### 实时额度 / 余额（厂商直读）

内置适配器（`lib/providers/`，端点与鉴权 2026-08-25 核实）：

- **额度类**（订阅制 Code 计划）：OpenCode Go / OpenAI Codex / Claude Code / GitHub Copilot / 智谱 Coding Plan / MiniMax Token Plan / ClinePass —— 卡片直接展示**订阅商接口返回的额度值**：每个窗口 5h/周/月的**实际已用百分比**与**重置时间**，另附供应商特有额度（Codex 代码评审、Claude Opus/Design 周窗口、Copilot Premium/Chat 快照、智谱 MCP 月度次数）；
- **余额类**（按量 Token 计划）：DeepSeek / Moonshot —— 展示**真实账户余额**（钱包可用余额 + 充值/赠金拆分，随 $/¥ 切换自动换算）。

凭据**只读**复用本机登录态与凭据缝：

| 供应商 | 凭据来源 |
|---|---|
| OpenCode Go / DeepSeek / 智谱 / MiniMax / ClinePass / Moonshot | 环境变量或凭据缝：`OPENCODE_GO_API_KEY` / `DEEPSEEK_API_KEY` / `ZHIPU_API_KEY` / `MINIMAX_API_KEY`（兜底 `MINIMAX_CN_API_KEY`） / `CLINEPASS_API_KEY` / `MOONSHOT_API_KEY` |
| OpenAI Codex | 本机 `~/.codex/auth.json` 登录态 |
| Claude Code | 本机 `~/.claude/.credentials.json` 登录态 |
| GitHub Copilot | `GH_TOKEN` / `GITHUB_TOKEN` / `gh` 配置 |

**余额卡自动出现**：只要凭据缝（`$DSH_HOME/.credentials.yaml`）配置了 `DEEPSEEK_API_KEY` / `MOONSHOT_API_KEY`，即使该 provider 未出现在会话日志中（例如经 OpenCode Go 网关使用），也会自动生成 token 计划卡展示真实账户余额。登录态缺失或接口失败时卡片显示原因并回退本地配额行。Codex/Claude/Copilot 为非公开/逆向接口（`chatgpt.com`、`api.anthropic.com`、`api.github.com`），随时可能变化，**失败不崩溃**。

**费用口径**：Code 计划按**订阅费**、Token 计划按**估算用量**计入「预计花费（月）」；"按 token 估算"仍单独展示用于对比。官方未公布额度的计划（如 Claude Code）显示**档位表**而非进度条；额度按官方周期（天/周/月）计量。

## 工作原理

- **服务端**（`lib/index.js`）注册为 Typert Remote 服务 `usageStats`（通过网关的 SRC 发现机制，无需生成描述符文件）。
- **浏览器端**（`lib/client.js`）先挂载自身的严格 `usageStats` 贡献，再通过精确的 `remote.usageStats` 子服务注入取得 client；静态注入的 `remote.session` 用于同步模型目录价格。
- **悬浮窗口**通过插件自己的 React root 挂在 `document.body` 上（`position: fixed; right: 20px; bottom: 20px`），卸载时自动移除。
- **数据回放**：直接回放 `$DSH_HOME/sessions` 下所有会话的持久化日志（zstd 分帧逐帧解码），按 token-meter 语义聚合：`assistant/chunk` 的 usage 为早期样本，`assistant/message` 的 usage 为同一 (turn, step) 的**最终样本并替换**早期样本，因此不会重复计数；当前内存中的活动会话事件也会合并进来。
- **计费**：费用 = Σ(各桶 token × 对应单价 / 1e6)，单价解析**按提供商自动匹配**：先找 (provider, model) 精确行，再找通用 model 行，最后回退默认单价——每个 AI 提供商（如 opencode-go 与 openai-codex）都按其官方价目各自计费，互不干扰。
- **统计维度**：总账 / 按提供商 / 按模型 / 按小时（0 填充的连续时间序列，用于曲线图）/ 按天 / 按会话 / 最近调用 / 性能（每步首字延时 TTFT、生成速度 tokens/s、总延迟，按模型与按小时聚合）/ 会话 × 模型明细。
- **性能口径**：TTFT = 请求（`request/header`）→ 首个内容 chunk；生成时长 = 首 → 末内容 chunk；tokens/s = 输出 token ÷ 生成时长。工具调用后的续写步骤没有独立请求日志，其 TTFT 以 `step/start` 为起点**估算**（样本带 `ttftEstimated` 标记）。
- **快照缓存**：按「会话文件大小 + mtime + 活动会话事件数」做签名缓存，数据未变时直接返回缓存。

## 安装

`0.6.6` 面向 DeepSeek Harness `0.1.3-alpha.1`；部署时应让所有 Harness peer 来自同一运行时版本。

插件包声明了 `dsh.bundle` 清单，`dsh plugin add` 后由 CLI 自动挂载进 profile 层——**无需手动编辑任何配置文件**：

```bash
# 1. 安装到 web profile（pnpm 转发，支持 npm 包 / github:owner/repo / 本地路径）
dsh plugin --profile web add dsh-spend

# 2. 验证已挂载（组合配置中出现 usage-stats 行）
dsh --profile web --dump-config | grep usage-stats

# 3. 重启 dsh web（改动需要重启加载，HMR 对插件不生效）
dsh web
```

也可以从源码安装：`dsh plugin --profile web add github:sdwhwzp/dsh-spend`（或本地路径 `-w /path/to/dsh-spend`）。

**覆盖默认配置**：插件内置供应商知识库自动识别价格与计费计划（见上），一般无需配置。需要覆盖时，在 `~/.dsh/profiles/web/cordis.patch.yml` 中加入同 id（`usage-stats`）的 insert 行即可——用户层在 bundle 层之后应用，同名行覆盖生效。配置项见下节。

## 配置

`cordis.patch.yml` 中 `usage-stats` 行的 `config`（当前已写入官方价，见「价格来源」）：

```yaml
config:
  currency: USD            # 服务端基准货币（费用按 USD 计算；UI 内可自由切换 $ / ¥ 展示）
  usdCnyRate: 7.2          # USD→CNY 固定汇率（实时汇率拉取失败时的回退值）
  liveRate: true           # 服务端实时拉取 USD→CNY 汇率（6h 缓存）；false 时始终用固定值
  syncIntervalHours: 24    # 后台账本对账与模型价格同步周期
  priceVersion: 2026-08-27 # 写入个人账本的价格版本
  fxVersion: fixed-2026-08-21 # 写入个人账本的汇率版本
  pricing:                 # 按模型精确匹配的单价（每百万 token）
    - model: deepseek-v4-flash
      inputPerMillion: 0.14
      outputPerMillion: 0.28
      cacheReadPerMillion: 0.0028
      cacheWritePerMillion: 0
      searchPerCall: 0     # 单次全网搜索的均价（见下方说明），留 0 则只计次不计费
  defaultPricing:          # 未知模型的回退单价
    inputPerMillion: 0.14
    outputPerMillion: 0.28
    cacheReadPerMillion: 0.0028
    cacheWritePerMillion: 0
  maxSessions: 20          # 按会话统计最多展示行数
  maxRecentCalls: 50       # 最近调用最多展示行数
  seriesHours: 168         # 时间曲线窗口（小时，服务端按此出 0 填充连续序列；UI 可切换 24h/72h/7d）
  refreshSeconds: 30       # 悬浮窗自动刷新间隔（秒，>= 5）
  ledgerPath: /var/lib/dsh/spend-ledger.sqlite
  monthlyBudget: 50        # 可选部署总预算展示，不参与个人额度判断
  plans:                   # 计费计划：判断 Token Plan / Code Plan 并展示使用量与剩余量
    - provider: opencode-go
      type: token          # token 计费：已用费用（估算）；balance 为充值余额（可选）
      # balance: 100
    - provider: openai-codex
      type: code           # 订阅额度制：使用量取近 periodDays 天的实际消耗
      quotaRequests: 100   # 周期请求额度（也可用 quotaTokens 按 token 额度）
      periodDays: 7
  usageEndpoints:          # 订阅商实时额度接口（内置 opencode-go 默认值；其余内置适配器见注释）
    - provider: opencode-go
      url: https://opencode.ai/zen/go/v1/usage   # 官方额度端点（非公开文档 API）
      apiKeyEnv: OPENCODE_GO_API_KEY             # 可选：凭据名（默认 <PROVIDER>_API_KEY）
      timeoutMs: 15000                           # 可选：超时毫秒
```

> **实时额度/余额**：Code 计划按内置适配器（`lib/providers/`）直读订阅商接口——opencode-go（凭据缝 `OPENCODE_GO_API_KEY`）、openai-codex（本机 `~/.codex/auth.json`）、claude-sub（`~/.claude/.credentials.json`）、github-copilot（`GH_TOKEN`/`GITHUB_TOKEN`/`gh` 配置）、zhipu（`ZHIPU_API_KEY`）、minimax（`MINIMAX_API_KEY`，兜底 `MINIMAX_CN_API_KEY`）、clinepass（`CLINEPASS_API_KEY`）；卡片显示各窗口实际百分比与重置时间。Token 计划余额直读：deepseek（`DEEPSEEK_API_KEY`）、moonshot（`MOONSHOT_API_KEY`）。`usageEndpoints` 可覆盖内置地址/超时，或为自定义供应商走通用 Bearer-key 通道（`<PROVIDER>_API_KEY`）。仅当登录态缺失、超时或非 200 时回退本地配额行并提示原因。

> **计价行**可加可选 `provider` 字段做提供商精确匹配（如 `provider: openai-codex`），不带 provider 的行对任意提供商的同名模型生效；未匹配到任何行时回退 `defaultPricing`。Token Plan 的「剩余」= 配置的充值余额 − 累计已用费用；Code Plan 的「剩余」= 额度 − 周期内实际消耗。未配置 `plans` 的提供商不显示计划卡片（默认按 token 计费口径展示费用）。

## 价格来源与计费口径

> 单价均来自厂商官方定价页（2026-08-14 查证），已写入本地配置；费用 = Σ(各桶 token × 对应单价 / 1e6)。**下表为 2026-08-17 前的 legacy 价**；8/17 起 DeepSeek 自动按峰谷价计价（见下方 ⚡ 说明，provider 为 `deepseek` 或 `deepseek-official` 时均生效）：

| 模型 | 输入(未命中) | 输入(缓存命中) | 缓存写 | 输出 |
|---|---|---|---|---|
| deepseek-v4-flash | $0.14 | $0.0028 | 0* | $0.28 |
| deepseek-v4-pro | $0.435 | $0.003625 | 0* | $0.87 |
| deepseek-v4-flash-vision-exp | $0.435 | $0.003625 | 0* | $0.87 |
| gpt-5.6-sol | $5.00 | $0.50 | $6.25 | $30.00 |
| gpt-5.6-terra | $2.00 | $0.20 | $2.50 | $12.00 |
| gpt-5.6-luna | $0.20 | $0.02 | $0.25 | $1.20 |

### 全网搜索（web_search）的计价

`dsh-web-search-deepseek` 每执行一次搜索，会向 DeepSeek 另发一次 `deepseek-v4-flash` 调用，并在会话日志里留下 `web/deepseek-search-llm-request` 事件。这笔调用与主对话分开计费，但**日志只记录请求、不记录响应用量**，因此没有可用的 token 数——可计量的单位只有"派发次数"。

插件按此计次：搜索归属到发起它的那一步（因而继承该步的用户），并按**搜索自身的模型**解析价格行，取其 `searchPerCall`。DeepSeek 官方并未公布按次的搜索费（搜索按承载模型的 token 计费），所以 `searchPerCall` 是部署方设定的单次均价；默认 0，此时搜索只计次、不产生费用。要精确到 token，需要搜索提供方把响应用量也写进会话日志。

- DeepSeek：[官方定价页](https://api-docs.deepseek.com/quick_start/pricing/)（2026-08-14 抓取；峰谷表 2026-09-09 复核）。\*DeepSeek 的上下文硬盘缓存自动生效、**无单独缓存写入计费项**，故 `cacheWritePerMillion: 0`。
  Flash 系列有两张先后生效的表：**2026-08-17** 起引入峰谷，高峰为**每日** 9:00–12:00、14:00–18:00（北京时间），高峰价为闲时 2 倍；**2026-09-10 12:00** 起闲时降为每百万 token 缓存命中 ¥0.02 / 缓存未命中 ¥1 / 输出 ¥4（较前降 60% / 33.3% / 11.1%），高峰仍为 2 倍，但收窄为**工作日**同样两个时段，非工作日全天按闲时计。表中为按 7.2 汇率折算的美元价，`schedule.phases` 按调用自身时间戳选表，`peakDays` 表达工作日限制。
  `deepseek-v4-flash-vision-exp` 与 `deepseek-v4.1-flash-expires-on-0910` **与文本版 Flash 同价**（视觉无溢价，单图最多 384 token），不再沿用 V4 Pro 的内部折算价。
- OpenAI：[官方定价页](https://developers.openai.com/api/docs/pricing)（2026-09-09 复核）。GPT-6 Astra $10/$1/$50、GPT-5.6 Sol $4/$0.4/$20、Terra $2/$0.2/$12、Luna $0.2/$0.02/$1.2（输入/缓存读/输出，每百万 token）；Sol 此前表内记为 $5/$30，已按官方页下调。缓存写沿用文档记载的 1.25 倍输入。
- Kimi 编程套餐（`kimi-coding`）：官方两张表（platform.kimi.com，2026-09-09 复核）。[K2.7 Code](https://platform.kimi.com/docs/pricing/chat-k27-code) 256k 上下文，每百万 token 缓存命中 ¥1.30 / 未命中 ¥6.50 / 输出 ¥27；[K3](https://platform.kimi.com/docs/pricing/chat-k3) 1M 上下文、无分级，¥2 / ¥20 / ¥100。K2.7 Code HighSpeed 为标准版 2 倍（¥2.60 / ¥13 / ¥54）。`kimi-for-coding` 与 `kimi-for-coding-highspeed` 分别按 K2.7 Code 标准版与高速版计价，名字里带 K3 的路由按 K3 计价；模型名精确匹配，故每个路由同时登记套餐名与官方 API id。该 provider 此前无价表，这些模型都回退到默认价。
- OpenAI（旧条目）：[官方定价页](https://platform.openai.com/docs/pricing)（2026-07-30 降价后），缓存写 = 未命中输入 × 1.25。Luna 已降 80%（$1→$0.20 输入 / $6→$1.20 输出）。
- 智谱 GLM：[Z.AI 官方定价页](https://docs.z.ai/guides/overview/pricing)，`zai` / `z-ai` / `glm` provider 自动匹配智谱价表；缓存存储当前限时免费，因此缓存写为 0。
- ⚡ **DeepSeek 峰谷计价已内置**（2026-08-17 00:00 北京时间生效；高峰 09:00–12:00 / 14:00–18:00 本地时间，其余空闲为高峰一半）：v4-flash 高峰 $0.014(命中)/$0.44(未命中)/$1.32(输出)、空闲减半；v4-pro 高峰 $0.044/$1.32/$3.96、空闲减半。实验视觉路由 `deepseek-v4-flash-vision-exp` 按内部策略完全沿用 v4-pro 的 legacy 与峰谷价格，直到 DeepSeek 公布独立价格。计价行可带 `schedule`（`effectiveAt` + `peakHours` + `peak`/`offPeak` 价格），**每条调用按自身发生时刻与时段计价**——8/17 前按上表 legacy 价，之后按峰谷价，历史调用不重算（计费单价表中带"峰谷计价"徽章）。
- ⚠️ **OpenCode Go 是订阅制**（非按 token 计费）：其用量不按上表 token 单价扣费，而是消耗 $10/月订阅的美元额度（5h $12 / 周 $30 / 月 $60）——「按 token 估算」仅作相对占比参考，真实花费看「预计花费（月）」与计划卡片。
- 若你的 provider 经代理中转计费（非官方直连），请按代理实际账单覆盖对应模型的单价。

> 费用为按官方单价的**估算值**，仅作参考，非账单；页面底部亦有免责说明。

## 目录结构

```
dsh-spend/
├── package.json          # 双端声明：dsh.client（web 平台 + 注入边）、dsh.bundle 清单
├── cordis.patch.yml      # bundle 补丁：向 profile 插入 usage-stats 配置行
├── lib/
│   ├── index.js          # 服务端插件：UsageStatsService（Typert Remote）
│   ├── knowledge.js      # 供应商知识库：计划自动识别（Code/Token）
│   ├── ledger.js         # SQLite 个人消费账本、管理员价格覆盖与额度服务
│   ├── stats.js          # 纯回放/聚合/计费逻辑（可独立测试）
│   ├── providers.js      # 实时额度/余额适配器门面（历史导入面兼容）
│   ├── providers/        # 适配器实现（每厂商一个文件，共享 common.js）
│   │   ├── index.js      # 注册表：PROVIDER_USAGE（额度）/ PROVIDER_BALANCE（余额）
│   │   ├── common.js     # 共享工具（请求、鉴权、归一化）
│   │   ├── opencode.js           # OpenCode Go 实时额度（官方端点）
│   │   ├── oauth-codex.js        # OpenAI Codex 实时额度（逆向接口）
│   │   ├── oauth-claude.js       # Claude Code 实时额度（逆向接口）
│   │   ├── oauth-copilot.js      # GitHub Copilot 实时额度（逆向接口）
│   │   ├── quota-zhipu.js        # 智谱 Coding Plan 实时额度（官方端点）
│   │   ├── quota-minimax.js      # MiniMax Token Plan 实时额度（官方端点）
│   │   ├── quota-clinepass.js    # ClinePass 实时额度（官方端点）
│   │   ├── balance-deepseek.js   # DeepSeek 账户余额（官方端点）
│   │   └── balance-moonshot.js   # Moonshot 账户余额（官方端点）
│   └── client.js         # 浏览器 bundle（手写 __ModuleLoader__ 格式）
├── docs/screenshots/     # 界面截图
├── README.md             # 本文件（中文）
├── README.en.md          # 英文版
└── LICENSE               # MIT
```

## 说明与边界

- 统计口径与 harness 的 token-meter 投影一致：**仅统计带 provider usage 的调用**；reasoning 计入 output 桶的细分（如日志提供 `reasoningTokens`）。
- 计费为估算值，不是账单；缓存读按命中单价计费。
- 日志解码失败的会话会计入 `decodeErrors` 并在页脚提示。
- Codex/Claude/Copilot 额度接口为非公开/逆向接口，可能随时失效；适配器已做失败降级（显示原因并回退本地配额行），不会崩溃。

## License

[MIT](LICENSE)
